var menuLink,
	data={
			'option':'',
			'details':''
	},
	url="http://192.168.0.120/Anpas",
	iconBase="images/active.gif";

	var myLatLng={},
	marker;

	
	myLatLng= new google.maps.LatLng(18, -77.8);
	mapOptions={
		center: myLatLng,
		zoom: 14,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	};
	
	var m= new google.maps.Map(document.getElementById("googft-mapCanvas"), mapOptions);
	marker=new google.maps.Marker({
			position: myLatLng,
			title: '',
			icon: iconBase
	});
	

function Thread(url, data, possintent){
	$.ajax({
		url: DOMAIN+url,
		cache:false,
		type: 'POST',
		data: data,
		success: function(return_data, textStatus, jqXHR){
			return_data= JSON.parse(return_data);
			switch(possintent){

			
			}
		},
		complete: function(return_data, textStatus, jqXHR){
			
		
		},
		error: function(jqXHR,textStatus,errorThrown){
			console.log(errorThrown);
		}
	});
	return false;
}


function Process(return_data, type){
	var item=[];
	if(type=="notification"){
		$.each(return_data, function(key, val){
			if(return_data.message== undefined){
				
			}else{
				
			}
		});		
	}
}

function geoLocation(post){
	if(window.navigator){
		navigator.geolocation.getCurrentPosition(geoLocation,geoLocationError);
	}
}
function geoLocationError(x){
	
	console.log("Error: "+x.code+" error message: "+x.message);
	
}

function geoLocationPosition(post){
	var latitude= post.coords.latitude;
	var lontitude= post.coords.longitude;
	var accuracy= post.coords.accuracy;

	marker.setPosition( new google.maps.LatLng(latitude, lontitude));
	m.panTo(new google.maps.LatLng(latitude, lontitude));

}


function Search(data){
	
	Thread(url, data, "search");
	
}
	

$(document).ready(function(){
	geoLocation();
	
	
	
	
	$(".nav_item a").on("click",function(){
		menuLink= this.id;
		console.log(menuLink);
		$("."+menuLink).toggleClass("hidden");
	});
	
	$("[type='search']").change(function(){
		console.log("ok");
		var text=$("[type='search']").attr('value');
		if(text==""){
			
			
		}else{
			data={"option":"search",
					"details":{
							"search_option": $(".search_select option:selected").html(),
							"search_details":text
							}
			};
			Search(data);
			
		}
		
	});
	$("[type='search']").keyup(function(){
		var text=$("[type='search']").attr('value');
		if(text==""){
			
		}else{
			data={"option":"search",
					"details":{
							"search_option": $(".search_select option:selected").html(),
							"search_details":text
							}
			};
			Search(data);	
		}
	})
	
	//Changes in geolocation
	var timeout={ timeout: 6000};
	var watchId= navigator.geolocation.watchPosition(
											geoLocation,
											geoLocationError,
										timeout
											
											);

	var options={
		target: url+"/includes/booking.php",
		beforeSubmit: null,
		success: showRequest
			
	}
	
	$('.reservation').ajaxForm(options);
	function showRequest(formData, jqForm, options){
		
		
	};
	
	
	$("#logo").click(function(){
		$(".logo").toggleClass("hidden");
		data="";
		$.ajax({
			url: url+"/includes/process.php",
			cache:false,
			type: 'POST',
			data: data,
			success: function(return_data, textStatus, jqXHR){
				$(".logo").html(return_data);
			},
			complete: function(){
				
			},error: function(e){
				
				
			}
			});
		
	});
});



