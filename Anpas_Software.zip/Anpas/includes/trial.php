<?php 
ob_start();

	try{
		
		$soapClient=new SoapClient("http://192.168.0.118:8080/TourismWebServices/Tourism.asmx?WSDL");
		
		$x=($soapClient->getAttractionContact(1));
		$count= count($x);

		echo $count. " ";

	}catch (SoapFault $fault){
		
		echo "FAult: ".$fault;
		
	}


?>