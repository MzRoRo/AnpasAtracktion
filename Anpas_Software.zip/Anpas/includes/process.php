<?php
	//session_start();
	error_reporting(E_ALL);


	
	try{
		$clientUrl="";
		$namespace="";
		$elementName="Authentication";
		$authenticationHeader= array('Username'=>'');
		$option;
		
		$AttactionCount;
		$ClientData;
		$ActiveReservations;
		$getHotels;
		$currentReservations;
		$hotelsByParish;
		
		$soapClient=new SoapClient("http://192.168.0.118:8080/TourismWebServices/Tourism.asmx?WSDL");
		
		$x=($soapClient->getAttractionContact(1));
		$ActiveReservations=$soapClient->getActiveReservations();
		$getHotels=$soapClient->getHotels();
		
		$currentReservations=count($soapClient->getCurrentReservationFacebook("Opie Grant"));
		$hotelsByParish=count($soapClient->getHotelsByParish(706));
		
		$AttractionCount= count($x);
		$ActiveReservations= count($ActiveReservations);
		
		$trial= "<p>Number of Attraction: ".$AttractionCount. "</p><p>Number of Active Reservations: ".$ActiveReservations."</p><p>Number of Hotels in Westmoreland: ".$hotelsByParish."</p>";
		$trial.="<p>Number of Hotels in Clarendon: ".count($soapClient->getHotelsByParish(706))."</p>";
		
		echo $trial;
		
		/*
		require_once("facebook.php");
		
		$facebook = new Facebook(array(
				'appId'  => 539100562807390,
				'secret' => 'b8e279a7dbe06cbafa2b869dafc29b68',
				'cookie' => true
		));
		
		# Let's see if we have an active session
		$session = $facebook->getSession();
		$user;
		$fname;
		$lname;
		$email;
		
		if(!empty($session)) {
		# Active session, let's try getting the user id (getUser()) and user info (api->('/me'))
			try{
			$uid = $facebook->getUser();
			$user = $facebook->api('/me');
				
			$fname=$user["first_name"];
			$lname=$user["last_name"];
			$email=$user_profile["email"];
				
			} catch (Exception $e){}
		
			if(!empty($user)){
			# User info ok? Let's print it (Here we will be adding the login and registering routines)
				print_r($user);
			} else {
			# For testing purposes, if there was an error, let's kill the script
				die("There was an error.");
			}
			} else {
		# There's no active session, let's generate one
				$login_url = $facebook->getLoginUrl();
				header("Location: ".$login_url);
			}
		
		*/
		
		/*
		if(!isset($_POST['Data'])){
		//	echo "Post option not set";	
			
		}else{
			$option=$_POST['Data'];
			$Client_Data=json_decode($_POST['Data']);
				
			switch($Client_Data->option){
				case 'search':
					
					
					
					
					break;
				case 'login':
					
					
					break;
				case 'admin_login':
					
					
					break;
				case '':
				
				
				break;
				case 'view_reports':	//Area used to view reports
					
					
					break;
				default:
					
					
				//	echo "Invalid option selected :".$Client_Data->option;
					break;	
			}
		}*/
	}catch(SoapFault $fault){
		echo "Soap error occured :".$fault;
		printf_r($fault);
	}

?>

