<?php
	require_once('fpdf/fpdf.php');

//CONSTANTS

//define("DOMAIN","");
/*define("DOMAIN_EMAIL","http://www.utechsapna.com/bootcamp/");

define("DB_SERVER","localhost");
define("DB_USER","utechsap");
define("DB_PASSWORD","S@pn@'sMur4l");
define("DB_NAME","utechsap_SAPNA_REGISTRATION");
*/
define("MAX_FILE_SIZE",8388608);	//The maximum file size they are allowed to upload
define("TRANSCRIPT","Transcript");	//The directory name of transcript folder
//define("DOMAIN","http://localhost/WEBSITES/SAPNA/");

define("DOMAIN","http://localhost/Bootcamp/");

define("DB_SERVER","localhost");
define("DB_USER","root");
define("DB_PASSWORD","petersala");
define("DB_NAME","SAPNA_REGISTRATION");

define("BOOTCAMP_YEAR", date("Y")-1);



//1. Create database connection

$connection=mysql_connect(DB_SERVER, DB_USER, DB_PASSWORD);
if(!$connection){
	die("Database connection failed: ".mysql_error());
}else
	//echo "Connection was successful";

//2. Select DB
$db_select=mysql_select_db(DB_NAME, $connection);
if(!$db_select){
	die("Database selection failed: ".mysql_error());
}


	//Functions for statements
	function mysql_prep(&$value){
		$magic_quotes_active=get_magic_quotes_gpc();
		$new_enough_php=function_exists("mysql_real_escape_string");
		if($new_enough_php){
			if($magic_quotes_active){
				$value= stripslashes($value);
			}
			$value=mysql_real_escape_string($value);
		}else{
			if(!$magic_quotes_active){
				$value=addslashes($value);
			}
		}
		return $value;
	}


function isValidEmail($email){
	return eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email);
}

function fetch_store_img($id){
	$dir="../images/user_pic/";
	if(file_exists($dir)){
	
	}else{
		mkdir('../images/user_pic', 0777);
	
	}
//	chmod("../images/user_pic", 0777);

	if(!$id){
		echo "<p class=\"error\">No id number was available</p>";
		return false;
	}
	$url="https://utechisas.utech.edu.jm/sipr//images/photos/".trim($id).".jpg";
	$img='../images/user_pic/'.trim($id).".jpg";
	
	if(file_put_contents($dir.trim($id).".jpg", file_get_contents($url))==false){
		echo "<p class=\"error\">Unable to add image to folder</p>";
		return false;
	}else{
		echo "<p class=\"ok\">Complete adding photo</p>";
		return true;
	}
	

}


function MailTo($to, $subject, $message,$headers=""){
	if($headers==""){
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";	
	}
	if(mail($to, $subject,$message , $headers)){
		echo "<p>Email was sent to {$to}</p>";
		return true;	
	}else{
		echo "<p class=\"error\">Email was not delivered to {$to}</p>";
		return false;
	}
}

function Close_connection(){
	global $connection;
	mysql_close($connection);
}

function File_Upload($id){
	//Check if directory exist if not upload it
	if(file_exists(TRANSCRIPT)){
	
	}else{
		mkdir(TRANSCRIPT, 0777);
	
	}
	
//	exec("chmod ".TRANSCRIPT." 0777);
//	chmod(TRANSCRIPT."/*", 0777);
	
	
	//Check..
	if($_FILES["transcript"]["error"] >0){
		echo "<p class=\"error\">Error : Fileupload error . Please contact us by using the contact us link at the bottom of the page or <a href=\"".DOMAIN."contactus.php\">click here</a></p>";
		return false;
	}else{
	
		//ERROR CHECKING
		if(!isset($_FILES['transcript']['name']))
		{
			echo "<p class=\"error\">No file name was found. Please retry uploading file</p><|>-1";
			return false;
		}
	//	if($_FILES['transcript']['type']){	//Type of file
			/*
			Note: For IE to recognize jpg files the type must be pjpeg, for FireFox it must be jpeg.


			*/
		
	//		echo "<p class=\"error\">Invalid file type. Please retry uploading file</p><|>-1";
	//		return false;
		
		
	//	}
		if($_FILES['transcript']['size']>= MAX_FILE_SIZE)	//50 MB
		{
			echo "<p class=\"error\">We require a transcript file. I assume it should not be more than more than 1MB. Please retry uploading file, and ensure that you do not upload any 'weirdo' things. Thank you</p><|>-1";
			return false;
		}
		
		
		$hold="";
		$extension=substr($_FILES['transcript']['name'] , strrpos($_FILES['transcript']['name'] , '.') +1);
		$_FILES['transcript']['name']=$id.".".$extension;

		if(file_exists(TRANSCRIPT."/".$_FILES['transcript']['tmp_name'])){
			global $hold;
			$hold= "<p class=\"ok\">".$_FILES["transcript"]["name"]." already exist however it will be overwritten</p>";
		}
		
				
		if(move_uploaded_file($_FILES['transcript']['tmp_name'], TRANSCRIPT."/".$_FILES['transcript']['name'])==false){
			global $hold;
			$hold.="<p class=\"error\">Unable to move".$_FILES["transcript"]["name"]." to appropriate destination. Please try again and if the problem persist, contact a Sapna representative.</p><|>-1";
			return false;
		}else{
			global $hold;
			$hold.="<p class=\"ok\">Transcript upload successful. Please continue with registration process.</p>";
			
		}
		
		//INSERT INTO DATABASE
		//PREP $_FILE info variables, anything that will be going to the database
		mysql_prep($_FILES['transcript']['name']);
		global $connection;
		$q=mysql_query("INSERT INTO Transcript ( id_no, transcript_url) VALUES ( '{$id}' , '{$_FILES['transcript']['name']}' )", $connection);
		if(!$q){
			global $hold;
			$hold.="<p class=\"error\">Error in database. Unable to add transcript information to databse. Please retry</p>";
			echo $hold."<|>-1";
			return false;
		}else{
			
		}
		echo $hold."<|>1";
		return true;
		
	}
	
}


function convert_to_pdf($variable){
		
	$pdf=new FPDF();
	$pdf->AddPage();

	$pdf->SetFont('Arial');
	$pdf->Cell(40,10,'Hello World!');
	$pdf->Output();

}

?>
